#!/usr/bin/env bash
# Manual foreground poller. Start it, leave it running, Ctrl+C to stop.
set -uo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
POLL_INTERVAL_SECONDS=60

echo "github-skill poller starting. Polling every ${POLL_INTERVAL_SECONDS}s."
echo "Log: $SELF_DIR/poll-and-push.log"
echo "Ctrl+C to stop."
echo

trap 'echo; echo "Stopped."; exit 0' INT TERM

while true; do
  bash "$SELF_DIR/push-once.sh"
  sleep "$POLL_INTERVAL_SECONDS"
done
